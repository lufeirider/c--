// dll.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "stdio.h"
int AddNum(int a,int b)
{
	printf("this is AddNum function\n");
	return 0;
}

int SubNum(int a,int b)
{
	printf("this is SubNum funtcion\n");
	return 0;
}

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

