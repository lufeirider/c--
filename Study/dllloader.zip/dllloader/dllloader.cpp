// dllloader.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
//#pragma comment(lib,"dll.lib")

//__declspec(dllimport) int AddNum(int,int);
//__declspec(dllimport) int SubNum(int,int);

#include "windows.h"
typedef int(*NumAdd)(int,int);
typedef int(*NumSub)(int,int);

int main(int argc, char* argv[])
{
//	AddNum(1,1);
//	SubNum(1,1);
	NumAdd add;
	NumSub sub;
	add = (NumAdd)GetProcAddress(LoadLibrary("dll.dll"),"AddNum");
	add(1,1);
	return 0;
}
