// HUTCheck.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#pragma comment(linker,"/subsystem:\"Windows\" /entry:\"mainCRTStartup\"")

#include <windows.h>

#define MAXSIZE 1024

#include <wininet.h>
#pragma comment(lib, "Wininet.lib") 


#include "iphlpapi.h" 
#pragma comment(lib,"Iphlpapi.lib")
#pragma comment(lib,"Ws2_32.lib")



typedef HANDLE(WINAPI* ICMPCREATEFILE)(VOID);
typedef BOOL(WINAPI* ICMPCLOSEHANDLE)(HANDLE);
typedef DWORD(WINAPI* ICMPSENDECHO)(HANDLE, DWORD, LPVOID, WORD, PIP_OPTION_INFORMATION, LPVOID, DWORD, DWORD);

//��������ָ�뺯��   
ICMPCREATEFILE pIcmpCreateFile;
ICMPCLOSEHANDLE pIcmpCloseHandle;
ICMPSENDECHO pIcmpSendEcho;

// �������ܣ���ʼ��ICMP������
BOOL InitIcmp()
{
	HINSTANCE hIcmp = LoadLibraryA("ICMP.DLL");
	if (hIcmp == NULL)

	{
		return false;

	}
	pIcmpCreateFile = (ICMPCREATEFILE)GetProcAddress(hIcmp, "IcmpCreateFile");
	pIcmpCloseHandle = (ICMPCLOSEHANDLE)GetProcAddress(hIcmp, "IcmpCloseHandle");
	pIcmpSendEcho = (ICMPSENDECHO)GetProcAddress(hIcmp, "IcmpSendEcho");
	if ((pIcmpCreateFile == NULL) || (pIcmpCloseHandle == NULL) || (pIcmpSendEcho == NULL))
		return false;
	return true;
}


// �������ܣ��ж��Ƿ���pingͨIP
// ����������IP��ַ������
BOOL ICMPPing(char* host)
{
	DWORD timeOut = 1000;                                              //���ó�ʱ   
	ULONG hAddr = inet_addr(host);                                     //�����IP��ַ��ֱ��ת��   
	if (hAddr == INADDR_NONE)
	{
		hostent* hp = gethostbyname(host);                             //�������������DNS������IP��ַ   
		if (hp)
			memcpy(&hAddr, hp->h_addr_list, hp->h_length);             //IP��ַ   
		else
		{
			return false;
		}
	}
	HANDLE hIp = pIcmpCreateFile();
	IP_OPTION_INFORMATION ipoi;
	memset(&ipoi, 0, sizeof(IP_OPTION_INFORMATION));
	ipoi.Ttl = 128;                  //Time-To-Live   

	unsigned char pSend[36];                                                                   //���Ͱ�   
	memset(pSend, 'E', 32);

	int repSize = sizeof(ICMP_ECHO_REPLY) + 32;
	unsigned char pReply[100];                                                                 //���հ�   
	ICMP_ECHO_REPLY* pEchoReply = (ICMP_ECHO_REPLY*)pReply;

	DWORD nPackets = pIcmpSendEcho(hIp, hAddr, pSend, 32, &ipoi, pReply, repSize, timeOut);             //����ICMP���ݱ���   

	if (pEchoReply->Status != 0)                                                                  //��ʱ������������������ICMP ����Ŀ������������  
	{
		pIcmpCloseHandle(hIp);
		return false;
	}

	pIcmpCloseHandle(hIp);
	return true;
}


void urlopen(char* url)
{
	HINTERNET hSession = InternetOpenA("UrlTest", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
	if (hSession != NULL)
	{
		HINTERNET hHttp = InternetOpenUrlA(hSession, url, NULL, 0, INTERNET_FLAG_DONT_CACHE, 0);
		if (hHttp != NULL)
		{
			InternetCloseHandle(hHttp);
			hHttp = NULL;
		}
		InternetCloseHandle(hSession);
		hSession = NULL;
	}
}

void ICMPCheck(char* ip)
{
	char url[255] = { 0 };
	strcpy(url, "http://127.0.0.1/check.php?ip=");
	strcat(url, ip);

	InitIcmp();
	if (ICMPPing(ip) == true)
	{
		printf("ok\n");
		urlopen(url);
		printf(url);
	}
	else
	{
		printf("no\n");
	}
}

static DWORD WINAPI thread_access(LPVOID args)
{
	char* ip;
	ip = (char*)args;

	char url[255] = { 0 };
	strcpy(url, "http://127.0.0.1/check.php?ip=");
	strcat(url, ip);

	InitIcmp();
	if (ICMPPing(ip) == true)
	{
		printf("ok\n");
		urlopen(url);
		printf(url);
	}
	else
	{
		printf("no\n");
	}
	return 1;
}

int main()
{
	while (true)
	{
		DWORD id;
		HANDLE hThread = CreateThread(NULL, 0, thread_access, "192.168.193.1", 0, &id);
		hThread = CreateThread(NULL, 0, thread_access, "192.168.181.1", 0, &id);
		hThread = CreateThread(NULL, 0, thread_access, "172.22.128.235", 0, &id);
		Sleep(3000);
	}
    return 0;
}

